#!/bin/bash

# apt-get update

# Install GIT
apt-get install -y git

# Config mosquitto: https://www.digitalocean.com/community/tutorials/how-to-install-and-secure-the-mosquitto-mqtt-messaging-broker-on-ubuntu-16-04
sudo apt-get install -y mosquitto mosquitto-clients